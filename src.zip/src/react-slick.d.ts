// src/react-slick.d.ts
declare module 'react-slick';
